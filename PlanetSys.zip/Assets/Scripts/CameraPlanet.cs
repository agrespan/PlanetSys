﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraPlanet : MonoBehaviour
{
    private GameObject influenceArea;
    private Rigidbody rb;
    public float forceAmp;
    public float influenceAreaSize;
    public int massMultiplier;

    // Start is called before the first frame update
    void Start()
    {
        
        influenceArea = gameObject.transform.Find("InfluenceArea").gameObject;
        influenceAreaSize = influenceAreaSize / transform.lossyScale.x;
        rb = GetComponent<Rigidbody>();
        rb.mass = transform.lossyScale.x * massMultiplier * Random.Range(0.5f,1.0f); ; 
        influenceArea.transform.localScale = new Vector3(influenceAreaSize, influenceAreaSize, influenceAreaSize);
        rb.AddRelativeTorque(0, -50000 * rb.mass,0);
    }

    public void SetGlobalScale(Transform transform, Transform reference,Vector3 globalScale)
    {
        transform.localScale = Vector3.one;
        transform.localScale = new Vector3(globalScale.x / reference.lossyScale.x, globalScale.y / reference.lossyScale.y, globalScale.z / reference.lossyScale.z);
    }

    // Update is called once per frame
    void Update()
    {
        

    }


    private void OnTriggerStay(Collider other)
    {
        float force;
        float mass = other.GetComponentInParent<Rigidbody>().mass;
        float distance = Vector3.Distance(other.transform.position, transform.position);
        Vector3 direction = other.transform.position - transform.position;
        force = mass / (distance * distance);

        rb.AddForce(direction * force * forceAmp);            
    }
       

}


