﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour
{
    public GameObject target;
    private GameObject positionRef;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        positionRef = GameObject.FindGameObjectWithTag("Planet");
        Vector3 newPosition = new Vector3(0 + (positionRef.transform.position.x), 1000 - (positionRef.transform.position.x), 1000 - (positionRef.transform.position.x * 0.1f));
        transform.position = Vector3.Lerp(transform.position, newPosition, 0.01f);
        transform.LookAt(target.transform.position);

    }
}
