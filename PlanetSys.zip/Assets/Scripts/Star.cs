﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Star : MonoBehaviour
{
    // Start is called before the first frame update

    Rigidbody rb;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        //rb.AddTorque(0, 2000000 * rb.mass, 0);
        rb.angularVelocity = new Vector3(0,0.5f,0);

        float randomTime = Random.Range(0.5f, 1.0f) * 50;
        Debug.Log(randomTime);
        //InvokeRepeating("Explode", randomTime, randomTime);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Explode()
    {
        Vector3 explodePosition = transform.position;
        Collider[] colliders = Physics.OverlapSphere(explodePosition, 600);

        foreach(Collider hit in colliders)
        {
            Rigidbody colliderRB = hit.GetComponent<Rigidbody>();
            if (colliderRB)
            {
                colliderRB.AddExplosionForce(500, explodePosition, 600);
            }
            
        }
        
    }

}
