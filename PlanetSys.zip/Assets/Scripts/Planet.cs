﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Planet : MonoBehaviour
{
    private GameObject influenceArea;
    private Rigidbody rb;
    public float forceAmp;
    public float influenceAreaSize;
    public float destroyLimit;
    public int massMultiplier;
    public float resistanceXmassa = 0.1f;
    public float originalResistance;
    public GameObject explosionPrefab;
    public GameObject miniPlanet;

    // Start is called before the first frame update
    void Start()
    {
        originalResistance = resistanceXmassa;
        influenceArea = gameObject.transform.Find("InfluenceArea").gameObject;
        influenceAreaSize = influenceAreaSize / transform.lossyScale.x;
        rb = GetComponent<Rigidbody>();
        rb.mass = transform.localScale.x * massMultiplier * Random.Range(0.5f,1.0f); ; 
        influenceArea.transform.localScale = new Vector3(influenceAreaSize, influenceAreaSize, influenceAreaSize);        
        rb.AddForce(9000 * rb.mass,0, 0);
        InvokeRepeating("DestroyLostPlanets",10,10);
        resistanceXmassa = resistanceXmassa * rb.mass;
        Invoke("EnableCollider",2);
    }


    // Update is called once per frame
    void Update()
    {
        

    }

    private void OnCollisionEnter(Collision collision)
    {
        //Debug.Log("rb "+rb.velocity);
        GameObject other = collision.gameObject;
        
        GameObject explosion = Instantiate(explosionPrefab, collision.GetContact(0).point, Quaternion.identity);
        explosion.transform.localScale = new Vector3(rb.mass , rb.mass, rb.mass) * (collision.relativeVelocity.magnitude / 1000);
        

        if (other.name != "Star")
        {
            explosion.GetComponent<Rigidbody>().velocity = rb.velocity/2;
            //Debug.Log("exp " + explosion.GetComponent<Rigidbody>().velocity);
            if (transform.localScale.x < 10) // Se este Planeta estiver pequeno demais poderá ser absorvido pelo outro
            {
                if (other.transform.localScale.x > 10 || gameObject.GetInstanceID() > other.GetInstanceID())
                {   // Sempre que o outro objeto for menor que 10 ele vai entrar nesse laço tb. Por isso escolho sempre um deles comparando o id
                    other.transform.localScale = new Vector3(other.transform.localScale.x + transform.localScale.x, other.transform.localScale.y + transform.localScale.y, other.transform.localScale.z + transform.localScale.z);
                    other.GetComponent<Planet>().resistanceXmassa = other.GetComponent<Planet>().originalResistance + originalResistance;
                    Destroy(gameObject);
                }
                
            }
            else
            {
                resistanceXmassa = resistanceXmassa - (collision.relativeVelocity.magnitude);
                if (resistanceXmassa < 0)
                {
                    gameObject.GetComponent<MeshRenderer>().enabled = false;

                    GameObject miniPlanet1 = Instantiate(miniPlanet, transform.position + (Vector3.left * rb.mass  * 2), Quaternion.identity);
                    GameObject miniPlanet2 = Instantiate(miniPlanet, transform.position + (Vector3.right * rb.mass * 2), Quaternion.identity);
                    

                    miniPlanet1.transform.transform.localScale = transform.lossyScale * 0.8f;
                    miniPlanet2.transform.transform.localScale = transform.lossyScale * 0.8f;

                    miniPlanet1.GetComponent<Planet>().miniPlanet = miniPlanet;
                    miniPlanet2.GetComponent<Planet>().miniPlanet = miniPlanet;

                    miniPlanet1.GetComponent<Renderer>().material = GetComponent<Renderer>().material;
                    miniPlanet2.GetComponent<Renderer>().material = GetComponent<Renderer>().material;

                    miniPlanet1.GetComponent<Rigidbody>().velocity = rb.velocity;
                    miniPlanet2.GetComponent<Rigidbody>().velocity = rb.velocity;
                    miniPlanet1.GetComponent<Rigidbody>().AddExplosionForce(200 * rb.mass, transform.position, 200);
                    miniPlanet2.GetComponent<Rigidbody>().AddExplosionForce(200 * rb.mass, transform.position, 200);

                    Destroy(gameObject);

                }
            }
        }
        if (collision.gameObject.name =="Star")
        {
           Explode();
        }
        
        
    }

    private void OnTriggerStay(Collider other)
    {
        float force;
        float mass = other.GetComponentInParent<Rigidbody>().mass;
        float distance = Vector3.Distance(other.transform.position, transform.position);
        Vector3 direction = other.transform.position - transform.position;
        force = mass / (distance * distance);

        rb.AddForce(direction * force * forceAmp);            
    }

    void DestroyLostPlanets()
    {
        if (transform.position.x > destroyLimit || transform.position.x < -destroyLimit || transform.position.y > destroyLimit || transform.position.y < -destroyLimit || transform.position.z > destroyLimit || transform.position.z < -destroyLimit)
        {
            Destroy(gameObject);
        }
    }
       

    public void ResetResistance()
    {
        resistanceXmassa = originalResistance * rb.mass;
    }

    void Explode()
    {
        
        Vector3 explodePosition = transform.position;      

        Collider[] colliders = Physics.OverlapSphere(explodePosition, 600);

        foreach (Collider hit in colliders)
        {
            Rigidbody colliderRB = hit.GetComponent<Rigidbody>();
            if (colliderRB)
            {
                colliderRB.AddExplosionForce(rb.mass*10, explodePosition, 300);
            }

        }

        Destroy(gameObject);
    }

    void EnableCollider()
    {
        GetComponent<SphereCollider>().enabled = true;
    }
}


