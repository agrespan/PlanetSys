﻿using UnityEngine;

public class Planet : MonoBehaviour
{
    private GameObject influenceArea; // Objeto de colisão Trigger para ativar atração gravitacional Força = massa / (distância^2)
    private Rigidbody rb;
    public float influenceAreaSize; // Tamanho do objeto infuenceArea
    public float destroyLimit; // Limite de distância da estrela para que o planeta seja destruído e libere memória
    public float resistance; // Vida do planeta
    public float originalResistance; // Resistência salva no Start
    public GameObject explosionPrefab; // Explosão
    public GameObject miniPlanet; // Prefab usado quando o planeta se divide ao colidir

    void Start()
    {        
        originalResistance = resistance;
        

        // Mantém a área de influência (filho) proporcional a escala do planeta (parent)
        influenceArea = gameObject.transform.Find("InfluenceArea").gameObject;
        influenceAreaSize = influenceAreaSize / transform.localScale.x;
        influenceArea.transform.localScale = new Vector3(influenceAreaSize, influenceAreaSize, influenceAreaSize);

        // Mantém massa razoavelmente proporcional à escala com Random
        rb = GetComponent<Rigidbody>();
        rb.mass = transform.localScale.x * Random.Range(0.5f,1.0f); 


        // Aplica força inicial lateral para que o planeta não vá direto pra estrela
        rb.AddForce(9000 * rb.mass,0, 0);

        // Deixa a resistencia proporcional à massa
        resistance = resistance * rb.mass;

        // Destroi planetas muito distantes a cada 10 segundos
        InvokeRepeating("DestroyLostPlanets",10,10);
        
        // Ativa colisor apenas 2 segundos após criação do planeta para evitar problemas no Instantiate
        Invoke("EnableCollider",2);
    }


    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {

        GameObject other = collision.gameObject;
        
        // Instancia explosão
        GameObject explosion = Instantiate(explosionPrefab, collision.GetContact(0).point, Quaternion.identity);
        // Tamanho da explosão proporcional à massa e à intensidade da pancada
        explosion.transform.localScale = new Vector3(rb.mass , rb.mass, rb.mass) * (collision.relativeVelocity.magnitude / 2000);
        

        if (other.name != "Star")
        {
            
            explosion.GetComponent<Rigidbody>().velocity = rb.velocity/2;


            if (transform.localScale.x < 10) // Se este Planeta estiver pequeno demais poderá ser absorvido pelo outro
            {
                // Sempre que o outro objeto for menor que 10 ele vai entrar nesse laço tb. Por isso escolho sempre um deles comparando o id
                if (other.transform.localScale.x > 10 || gameObject.GetInstanceID() > other.GetInstanceID())
                {   // Aumenta a escala do outro planeta
                    other.transform.localScale = new Vector3(other.transform.localScale.x + transform.localScale.x, other.transform.localScale.y + transform.localScale.y, other.transform.localScale.z + transform.localScale.z);
                    // Reseta resistencia do outro planeta
                    other.GetComponent<Planet>().resistance = other.GetComponent<Planet>().originalResistance + originalResistance;
                    Destroy(gameObject);
                }
                
            }
            else // Se o planeta tiver tamanho suficiente si divide em 2
            {
                
                resistance = resistance - (collision.relativeVelocity.magnitude);
                if (resistance < 0)
                {
                    gameObject.GetComponent<MeshRenderer>().enabled = false;

                    // Instancia os mini planetas com uma pequena distancia proporcional à massa do planeta
                    GameObject miniPlanet1 = Instantiate(miniPlanet, transform.position + (Vector3.left * rb.mass  * 2), Quaternion.identity);
                    GameObject miniPlanet2 = Instantiate(miniPlanet, transform.position + (Vector3.right * rb.mass * 2), Quaternion.identity);
                    
                    // Seta o tamanho dos mini planetas
                    miniPlanet1.transform.transform.localScale = transform.lossyScale * 0.8f;
                    miniPlanet2.transform.transform.localScale = transform.lossyScale * 0.8f;

                    // Atribui o nested prefab já que por algum motivo pelo editor dá problema
                    miniPlanet1.GetComponent<Planet>().miniPlanet = miniPlanet;
                    miniPlanet2.GetComponent<Planet>().miniPlanet = miniPlanet;

                    // Atribui o mesmo material do planeta aos mini planetas
                    miniPlanet1.GetComponent<Renderer>().material = GetComponent<Renderer>().material;
                    miniPlanet2.GetComponent<Renderer>().material = GetComponent<Renderer>().material;

                    // Mantém mesma velocidade
                    miniPlanet1.GetComponent<Rigidbody>().velocity = rb.velocity;
                    miniPlanet2.GetComponent<Rigidbody>().velocity = rb.velocity;

                    // Aplica força de explosão nos miniplanetas
                    miniPlanet1.GetComponent<Rigidbody>().AddExplosionForce(200 * rb.mass, transform.position, 200);
                    miniPlanet2.GetComponent<Rigidbody>().AddExplosionForce(200 * rb.mass, transform.position, 200);

                    Destroy(gameObject);

                }
            }
        }
        if (collision.gameObject.name =="Star")
        {
            Destroy(gameObject);
        }
        
        
    }

    private void OnTriggerStay(Collider other)
    {
        // Aplica força de atração para todos os objetos que entrem em contato com o influenceArea
        
        float mass = other.GetComponentInParent<Rigidbody>().mass;
        float distance = Vector3.Distance(other.transform.position, transform.position);

        float force;
        force = mass / (distance * distance);

        Vector3 direction = other.transform.position - transform.position;
        rb.AddForce(direction * force);            
    }

    void DestroyLostPlanets()
    {
        if (transform.position.x > destroyLimit || transform.position.x < -destroyLimit || transform.position.y > destroyLimit || transform.position.y < -destroyLimit || transform.position.z > destroyLimit || transform.position.z < -destroyLimit)
        {
            Destroy(gameObject);
        }
    }
       

    public void ResetResistance()
    {
        resistance = originalResistance * rb.mass;
    }

    
    void EnableCollider()
    {
        GetComponent<SphereCollider>().enabled = true;
    }
}


